package com.www.mall.service.system;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.RC;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.Employee;
import com.xiaoleilu.hutool.util.IdcardUtil;
import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * Employee服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class EmployeeService extends BaseService implements com.www.mall.system.interf.EmployeeService {

	@Override
	public Response saveEmployee(Employee employee) {
		String idCard=employee.getIdCard();
		if(!IdcardUtil.isValidCard(idCard)){
			return Response.result(RC.PARAM_FAIL,"身份证号码无效");
		}
		employee.setBirthday(IdcardUtil.getBirthByIdCard(idCard));
		employee.setGender(IdcardUtil.getGenderByIdCard(idCard));
		
		Request request=Request.build("EmployeeService", "saveEmployee").from(employee).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateEmployee(Employee employee) {
		String idCard=employee.getIdCard();
		if(!IdcardUtil.isValidCard(idCard)){
			return Response.result(RC.PARAM_FAIL,"身份证号码无效");
		}
		employee.setBirthday(IdcardUtil.getBirthByIdCard(idCard));
		employee.setGender(IdcardUtil.getGenderByIdCard(idCard));		
		Request request=Request.build("EmployeeService", "updateEmployee").from(employee);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Employee> queryEmployeePage(int pageNumber, int pageSize,String name) {
		Request request=Request.build("EmployeeService", "queryEmployeePage").page(pageNumber, pageSize).set("name", name);
		Page<Employee> response=DBTrans.page(request, Employee.class);
		return response;
	}
	
	@Override
	public Employee queryEmployeeById(long empNo) {
		Request request=Request.build("EmployeeService", "queryEmployeeById").set("empNo", empNo);
		Employee response=DBTrans.bean(request, Employee.class);
		return response;
	}

	@Override
	public Response leaveEmployee(Employee employee) {
		Request request=Request.build("EmployeeService", "leaveEmployee").from(employee).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}
}