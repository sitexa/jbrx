package com.www.mall.service.system;

import java.util.List;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.common.shiro.principal.Admins;
import com.www.mall.system.dto.Role;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * 服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class RoleService extends BaseService implements com.www.mall.system.interf.RoleService {

	@Override
	public Response saveRole(Role role) {
		Request request=Request.build("RoleService", "saveRole").from(role).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateRole(Role role) {
		Request request=Request.build("RoleService", "updateRole").from(role).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Role> queryRolePage(int pageNumber,int pageSize,String roleName) {
		Request request=Request.build("RoleService", "queryRolePage").page(pageNumber, pageSize);
		if(roleName!=null){
			request.set("roleName", roleName);
		}
		Page<Role> page=DBTrans.page(request, Role.class);
		return page;
	}
	
	@Override
	public Role queryRoleById(long id) {
		Request request=Request.build("RoleService", "queryRoleById").set("id", id);
		Role result=DBTrans.bean(request,Role.class);
		return result;
	}
	
	@Override
	public List<Role> queryRoleByUser(Admins admins) {
		Request request=Request.build("RoleService", "queryRoleByUser").from(admins);
		List<Role> result=DBTrans.list(request,Role.class);
		return result;
	}

}