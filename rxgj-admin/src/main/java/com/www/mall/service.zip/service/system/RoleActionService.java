package com.www.mall.service.system;

import java.util.List;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.RoleAction;
import com.www.mall.system.dto.RoleMenuAction;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * 服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class RoleActionService extends BaseService implements com.www.mall.system.interf.RoleActionService {

	@Override
	public Response saveRoleAction(long roleId,RoleAction[] roleActions) {
		Request request=Request.build("RoleActionService", "saveRoleAction").set("roleId", roleId).set("roleActions",roleActions).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateRoleAction(RoleAction roleAction) {
		Request request=Request.build("RoleActionService", "updateRoleAction").set("roleAction",roleAction);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<RoleAction> queryRoleActionPage(int pageNumber,int pageSize) {
		Request request=Request.build("RoleActionService", "queryRoleActionById").page(pageNumber, pageSize);
		Page<RoleAction>  list=DBTrans.page(request, RoleAction.class);
		return list;
	}
	
	@Override
	public RoleAction queryRoleActionById(long id) {
		Request request=Request.build("RoleActionService", "queryRoleActionById").set("id", id);
		RoleAction list=DBTrans.list(request, RoleAction.class);
		return list;
	}
	
	@Override
	public List<RoleMenuAction> queryAllRoleMenuAction(RoleAction roleAction){
		Request request=Request.build("RoleActionService", "queryAllRoleMenuAction").from(roleAction);
		List<RoleMenuAction> list=DBTrans.list(request, RoleMenuAction.class);
		return list;
	}
}