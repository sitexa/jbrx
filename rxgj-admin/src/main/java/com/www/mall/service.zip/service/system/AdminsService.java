//package com.www.mall.service.system;
//
//import javax.inject.Singleton;
//
//import com.gavin.business.DBTrans;
//import com.gavin.model.Page;
//import com.gavin.model.Request;
//import com.gavin.model.Response;
//import com.www.mall.common.base.BaseService;
//import com.www.mall.common.shiro.principal.Admins;
//
//import io.jboot.aop.annotation.Bean;
//import io.jboot.core.rpc.annotation.JbootrpcService;
//
///**
// * ------------------------------
// * 管理员服务
// * ------------------------------
// * @author wdm  @date 2017年11月28日
// * @version 1.0
// */
//@Bean
//@Singleton
//@JbootrpcService
//public class AdminsService extends BaseService implements com.www.mall.system.interf.AdminsService {
//
//	@Override
//	public Response saveAdmins(Admins admins) {
//		if(admins.getEmail()==null){
//			admins.setRemark("请补全email,否则将不能登录");
//		}
//		Request request=Request.build("AdminsService", "saveAdmins").from(admins).currentTime();
//		Response response=DBTrans.execute(request);
//		return response;
//	}
//
//	@Override
//	public Response updateAdmins(Admins admins) {
//		if(admins.getEmail()==null){
//			admins.setEmail("");
//			admins.setRemark("请补全email,否则将不能登录");
//		}
//		Request request=Request.build("AdminsService", "updateAdmins").from(admins);
//		Response response=DBTrans.execute(request);
//		return response;
//	}
//	
//	@Override
//	public Page<Admins> queryAdminsPage(int pageNumber, int pageSize,String userName) {
//		Request request=Request.build("AdminsService", "queryAdminsPage").set("userName", userName).page(pageNumber, pageSize);
//		Page<Admins> page=DBTrans.page(request, Admins.class);
//		return page;
//	}
//	
//	@Override
//	public Admins queryAdminsById(Admins admins) {
//		Request request=Request.build("AdminsService", "queryAdminsById").set("empNo", admins.getEmpNo());
//		return DBTrans.bean(request,Admins.class);
//	}
//
//	@Override
//	public Admins queryAdminsByUserName(String loginName) {
//		Request request=Request.build("AdminsService", "queryAdminsByUserName").set("userName", loginName);
//		Admins admins=DBTrans.bean(request,Admins.class);
//		return admins;
//	}
//
//	@Override
//	public Response enableDisable(long empNo, int status) {
//		Request request=Request.build("AdminsService", "enableDisable").set("empNo",empNo).set("status", status);
//		Response response=DBTrans.execute(request);
//		return response;
//	}
//
//}