package com.www.mall.service.system;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.Upgrade;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * 系统升级服务
 * ------------------------------
 * @author wdm  @date 2018年01月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class UpgradeService extends BaseService implements com.www.mall.system.interf.UpgradeService {

	@Override
	public Response saveUpgrade(Upgrade upgrade) {
		upgrade.setVerCode(System.currentTimeMillis());//版本顺序号
		Request request=Request.build("UpgradeService", Upgrade.SAVE).from(upgrade).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateUpgrade(Upgrade upgrade) {
		Request request=Request.build("UpgradeService", Upgrade.UPDATE).from(upgrade);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Upgrade> queryUpgradePage(int pageNumber,int pageSize) {
		Request request=Request.build("UpgradeService", "queryUpgradePage").page(pageNumber, pageSize);
		Page<Upgrade> page=DBTrans.page(request, Upgrade.class);
		return page;
	}
	
	@Override
	public Upgrade queryUpgradeById(long id) {
		Request request=Request.build("UpgradeService", "queryUpgradeById").set("id", id);
		Upgrade response=DBTrans.bean(request, Upgrade.class);
		return response;
	}

	@Override
	public Upgrade queryUpgrade(Upgrade upgrade) {
		Request request=Request.build("UpgradeService", "queryUpgradeById").from(upgrade);
		Upgrade response=DBTrans.bean(request, Upgrade.class);
		return response;
	}

	@Override
	public Response revoke(long id) {
		Request request=Request.build("UpgradeService", "revoke").set("id", id);
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response release(long id) {
		Request request=Request.build("UpgradeService", "release").set("id", id);
		Response response=DBTrans.execute(request);
		return response;
	}
}