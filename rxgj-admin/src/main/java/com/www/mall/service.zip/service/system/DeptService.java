package com.www.mall.service.system;

import java.util.List;
import javax.inject.Singleton;
import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.Dept;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * Dept服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class DeptService extends BaseService implements com.www.mall.system.interf.DeptService {

	@Override
	public Response saveDept(Dept dept) {
		Request request=Request.build("DeptService", "saveDept").from(dept).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateDept(Dept dept) {
		Request request=Request.build("DeptService", "updateDept").from(dept);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Dept> queryDeptPage(int pageNumber, int pageSize,String deptName) {
		Request request=Request.build("DeptService", "queryDeptPage").page(pageNumber, pageSize).set("deptName", deptName);
		Page<Dept> page=DBTrans.page(request, Dept.class);
		return page;
	}
	
	@Override
	public Dept queryDeptById(long deptId) {
		Request request=Request.build("DeptService", "queryDeptById").set("id", deptId);
		Dept result=DBTrans.bean(request, Dept.class);
		return result;
	}

	@Override
	public List<Dept> queryAllDept() {
		Request request=Request.build("DeptService", "queryAllDept");
		List<Dept> result=DBTrans.list(request, Dept.class);
		return result;
	}
}