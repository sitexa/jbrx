package com.www.mall.service.system;

import java.util.List;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.Area;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * Area服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class AreaService extends BaseService implements com.www.mall.system.interf.AreaService {

	@Override
	public Response saveArea(Area area) {
		Request request=Request.build("AreaService", "saveArea").from(area).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateArea(Area area) {
		Request request=Request.build("AreaService", "updateArea").from(area);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Area> queryAreaPage(int pageNumber,int pageSize,String areaName) {
		Request request=Request.build("AreaService", "queryAreaPage").page(pageNumber, pageSize);
		Page<Area> page=DBTrans.page(request,Area.class);
		return page;
	}
	
	@Override
	public Area queryAreaById(long id) {
		Request request=Request.build("AreaService", "queryAreaById").set("id", id);
		Area bean=DBTrans.bean(request,Area.class);
		return bean;
	}

	@Override
	public List<Area> queryAreaByLevel(int areaLevel) {
		Request request=Request.build("AreaService", "queryAreaByType").set("areaLevel", areaLevel);
		List<Area> list=DBTrans.list(request, Area.class);
		return list;
	}

	@Override
	public List<Area> queryAreaByParentCode(String parentCode) {
		Request request=Request.build("AreaService", "queryAreaByParentCode").set("parentCode", parentCode);
		List<Area> list=DBTrans.list(request, Area.class);
		return list;
	}

	@Override
	public Response enableDisable(long id,int status) {
		Request request=Request.build("AreaService", "enableDisable").set("id",id).set("status", status);
		Response response=DBTrans.execute(request);
		return response;
	}
}