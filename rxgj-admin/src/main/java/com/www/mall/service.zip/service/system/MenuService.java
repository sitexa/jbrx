package com.www.mall.service.system;

import java.util.List;

import javax.inject.Singleton;

import org.apache.log4j.Logger;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.system.bean.Menu;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * 菜单服务
 * @author wangdongming
 */
@Bean
@Singleton
@JbootrpcService
public class MenuService implements com.www.mall.system.interf.MenuService {
	Logger logger=Logger.getLogger(MenuService.class);
	
	@Override
	public List<Menu> queryMenuListByLevel12() {
		Request request=Request.build("MenuService", "queryMenuListByLevel12");
		List<Menu> list=DBTrans.list(request,Menu.class);
		return list;
	}

	@Override
	public Response saveMenu(Menu menu) {
		Request request=Request.build("MenuService", "saveMenu").from(menu).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateMenu(Menu menu) {
		if(menu.getParentId()!=0){
			Request request=Request.build("MenuService", "queryMenuByParentId").from(menu);
			Menu parent=DBTrans.bean(request,Menu.class);
			if(parent==null){
				
			}else{
				String levelCode=parent.getString("levelCode")+"_"+menu.getId();
				menu.setLevelCode(levelCode);
				menu.setLevel(parent.getLevel()+1);
			}
		}
		Request request=Request.build("MenuService", "updateMenu").from(menu);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Menu> queryMenuPage(int pageNumber,int pageSize,String menuName) {
		Request request=Request.build("MenuService", "queryMenuPage").page(pageNumber, pageSize);
		if(menuName!=null){
			request.set("name", menuName);
		}
		Page<Menu> page=DBTrans.page(request, Menu.class);
		return page;
		
	}

	@Override
	public List<Menu> queryMenuParentList() {
		Request request=Request.build("MenuService", "queryMenuParentList");
		List<Menu> result=DBTrans.list(request, Menu.class);
		return result;
	}

	@Override
	public Menu queryById(Menu menu) {
		Request request=Request.build("MenuService", "queryById").from(menu);
		Menu result=DBTrans.bean(request, Menu.class);
		return result;
	}

	@Override
	public Response saveMenus(List<Menu> menus) {
		Menu[] dms=new Menu[menus.size()];
		for (int i = 0; i < dms.length; i++) {
			dms[i]=menus.get(i);
		}
		Request request=Request.build("MenuService", "saveMenus").set("menus", dms).currentTime();
		Response result=DBTrans.execute(request);
		return result;
	}
	
	@Override
	public List<com.www.mall.system.dto.Menu> queryMenuByUser(long empNo) {
		Request request=Request.build("MenuService", "queryMenuByUser").set("empNo", empNo);
		List<com.www.mall.system.dto.Menu> list=DBTrans.list(request,com.www.mall.system.dto.Menu.class);
		return list;
	}
	
	@Override
	public List<com.www.mall.system.dto.Menu> queryUserMenu(long empNo) {
		Request request=Request.build("MenuService", "queryUserMenu").set("empNo", empNo);
		List<com.www.mall.system.dto.Menu> list=DBTrans.list(request,com.www.mall.system.dto.Menu.class);
		return list;
	}

}
