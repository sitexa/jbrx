package com.www.mall.service.system;

import java.util.List;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.Dictionary;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * 字典服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class DictionaryService extends BaseService implements com.www.mall.system.interf.DictionaryService {

	@Override
	public Response saveDictionary(List<Dictionary> dictionarys) {
		Dictionary[] dms=new Dictionary[dictionarys.size()];
		for (int i = 0; i < dictionarys.size(); i++) {
			dms[i]=dictionarys.get(i);
		}
		
		Request request=Request.build("DictionaryService", "saveDictionarys").set("dicts",dms).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateDictionary(Dictionary dictionary) {
		Request request=Request.build("DictionaryService", "updateDictionary").from(dictionary);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Dictionary> queryDictionaryPage(int pageNumber, int pageSize,String dictName) {
		Request request=Request.build("DictionaryService", "queryPage").page(pageNumber, pageSize).set("dictName", dictName);
		Page<Dictionary> page=DBTrans.page(request, Dictionary.class);
		return page;
	}
	
	@Override
	public Dictionary queryDictionaryById(long id) {
		Request request=Request.build("DictionaryService", "queryDictionaryById").set("id", id);
		Dictionary dictionary=DBTrans.bean(request, Dictionary.class);
		return dictionary;
	}
}