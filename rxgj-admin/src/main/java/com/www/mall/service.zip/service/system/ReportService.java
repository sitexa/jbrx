package com.www.mall.service.system;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.Report;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * 服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class ReportService extends BaseService implements com.www.mall.system.interf.ReportService {

	@Override
	public Response saveReport(Report report) {
		Request request=Request.build("MenuService", "saveReport").from(report).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateReport(Report report) {
		Request request=Request.build("MenuService", "updateReport").from(report);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Report> queryReportPage(int pageNumber,int pageSize) {
		Request request=Request.build("MenuService", "queryPage").page(pageNumber, pageSize);
		Page<Report> response=DBTrans.page(request,Report.class);
		return response;
	}
	
	@Override
	public Report queryReportById(long id) {
		Request request=Request.build("MenuService", "queryReportById").set("id", id);
		Report response=DBTrans.bean(request,Report.class);
		return response;
	}
}