package com.www.mall.service.system;

import java.util.List;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.Banner;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * 广告服务
 * ------------------------------
 * @author wdm  @date 2018年01月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class BannerService extends BaseService implements com.www.mall.system.interf.BannerService {

	@Override
	public Response saveBanner(Banner banner) {
		Request request=Request.build(service, "saveBanner").from(banner).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateBanner(Banner banner) {
		Request request=Request.build(service, "updateBanner").from(banner);
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Banner queryBannerById(long id) {
		Request request=Request.build(service, "queryBannerById").set("id", id);
		Banner bean=DBTrans.bean(request, Banner.class);
		return bean;
	}		
	
	@Override
	public List<Banner> queryBannerList(int bannerType) {
		Request request=Request.build(service, "queryBannerList").set("bannerType", bannerType).currentTime();
		List<Banner> list=DBTrans.list(request, Banner.class);
		return list;
	}

	@Override
	public Page<Banner> queryBannerPage(int pageNumber, int pageSize, String bannerName) {
		Request request=Request.build(service, "queryBannerPage").page(pageNumber, pageSize).set("bannerName", bannerName);
		Page<Banner> page=DBTrans.page(request, Banner.class);
		return page;
	}
	
	@Override
	public Response enableDisable(long id,int status) {
		Request request=Request.build(service, "enableDisable").set("id",id).set("status", status);
		Response response=DBTrans.execute(request);
		return response;
	}
}