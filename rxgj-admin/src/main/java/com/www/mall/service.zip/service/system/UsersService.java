package com.www.mall.service.system;


import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.common.shiro.principal.Users;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * Users服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class UsersService extends BaseService implements com.www.mall.system.interf.UsersService {

	@Override
	public Response saveUsers(Users users) {
		Request request=Request.build("UsersService", "saveUsers").from(users).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateUsers(Users users) {
		Request request=Request.build("UsersService", "updateUsers").from(users);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<Users> queryUsersPage(int pageNumber,int pageSize,String username) {
		Request request=Request.build("UsersService", "queryUsersPage").page(pageNumber, pageSize).set("username", username);
		Page<Users> response=DBTrans.page(request,Users.class);
		return response;
	}
	
	@Override
	public Users queryUsersById(long userId) {
		Request request=Request.build("UsersService", "queryUsersById").set("userId", userId);
		Users response=DBTrans.bean(request,Users.class);
		return response;
	}

	@Override
	public Users findByUserName(String username) {
		Request request=Request.build("UsersService", "findByUserName").set("username", username);
		Users response=DBTrans.bean(request,Users.class);
		return response;
	}
}
