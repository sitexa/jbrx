package com.www.mall.service.system;

import java.util.List;

import javax.inject.Singleton;

import org.apache.log4j.Logger;

import com.gavin.business.DBTrans;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.UserRole;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * UserRole服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class UserRoleService extends BaseService implements com.www.mall.system.interf.UserRoleService {
	private static Logger logger=Logger.getLogger(UserRoleService.class);

//	@Override
//	public Response saveUserRole(UserRole userRole) {
//		return DBTrans.execute(Request.build("UserRoleService", "saveUserRole").currentTime());
//	}

//	@Override
//	public Response updateUserRole(UserRole userRole) {
//		return DBTrans.execute(Request.build("UserRoleService", "updateUserRole").currentTime());
//	}
	
//	@Override
//	public Page<UserRole> queryUserRolePage(int pageNumber,int pageSize) {
//		return DBTrans.page(
//				Request.build("UserRoleService", "queryUserRolePage").page(pageNumber, pageSize),
//				UserRole.class);
//	}
//	
//	@Override
//	public UserRole queryUserRoleById(long id) {
//		return DBTrans.bean(
//				Request.build("UserRoleService", "queryUserRolePage").set("id", id),
//				UserRole.class);
//	}
	
	@Override
	public List<UserRole> queryUserRole(long userId) {
		Request request=Request.build("UserRoleService", "queryUserRole").set("userId", userId);
		return DBTrans.list(request, UserRole.class);
	}

	@Override
	public Response saveUserRoles(long userId,String roleNames,List<UserRole> list) {
		UserRole[] dms=new UserRole[list.size()];
		for (int i = 0; i < dms.length; i++) {
			dms[i]=list.get(i);
		}
		Request request=Request.build("UserRoleService", "saveUserRoles").set("userId", userId).set("roleNames", roleNames).set("userRoles", dms).currentTime();
		
		return DBTrans.execute(request);
	}

	@Override
	public UserRole queryRoleNameByIds(String roleIds) {
		Request request=Request.build("UserRoleService", "queryRoleNameByIds").set("roleIds", roleIds);
		return DBTrans.bean(request, UserRole.class);
	}
}