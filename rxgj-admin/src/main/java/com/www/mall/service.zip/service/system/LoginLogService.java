package com.www.mall.service.system;

import javax.inject.Singleton;

import com.gavin.business.DBTrans;
import com.gavin.model.Page;
import com.gavin.model.Request;
import com.gavin.model.Response;
import com.www.mall.common.base.BaseService;
import com.www.mall.system.dto.LoginLog;

import io.jboot.aop.annotation.Bean;
import io.jboot.core.rpc.annotation.JbootrpcService;

/**
 * ------------------------------
 * 登陆日志服务
 * ------------------------------
 * @author wdm  @date 2017年11月28日
 * @version 1.0
 */
@Bean
@Singleton
@JbootrpcService
public class LoginLogService extends BaseService implements com.www.mall.system.interf.LoginLogService {

	@Override
	public Response saveLoginLog(LoginLog loginLog) {
		Request request=Request.build("LoginLogService", "saveLoginLog").from(loginLog).currentTime();
		Response response=DBTrans.execute(request);
		return response;
	}

	@Override
	public Response updateLoginLog(LoginLog loginLog) {
		Request request=Request.build("LoginLogService", "updateLoginLog").from(loginLog);
		Response response=DBTrans.execute(request);
		return response;
	}
	
	@Override
	public Page<LoginLog> queryLoginLogPage(int pageNumber,int pageSize,long userId) {
		Request request=Request.build("LoginLogService", "updateLoginLog").page(pageNumber, pageSize).set("userId", userId);
		Page<LoginLog> page=DBTrans.page(request,LoginLog.class);
		return page;
	}
	
	@Override
	public LoginLog queryLoginLogById(long id) {
		Request request=Request.build("LoginLogService", "queryLoginLogById").set("id", id);
		LoginLog bean=DBTrans.bean(request,LoginLog.class);
		return bean;
	}
}